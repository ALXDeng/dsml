go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >> workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log
go clean --testcache
go test -v ./pkg/tests >>  workflow.log